     This file is the Read Me.txt file for...   JQueryMigrate 1.0
 
     The module will install JQuery Migrate 1.2.1
     Regards,

     John Hutton
     Hutton Engineering